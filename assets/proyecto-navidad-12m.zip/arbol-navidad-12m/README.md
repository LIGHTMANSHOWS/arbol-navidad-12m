# LIGHTMAN · Árbol musical de Navidad de 12 metros

Un único proyecto: visualizador 3D, medley navideño original, show sincronizado, propuesta técnica y presupuesto de planificación.

## Abrir la experiencia

Abre `dist/index.html` en un navegador con WebGL. La música, motor y modelo están dentro de la carpeta; no necesitas instalar dependencias para ver el show. Se incluyen fuentes tipográficas del sistema como respaldo si no hay internet. Pulsa **Vivir el espectáculo**: los navegadores requieren una acción del usuario para reproducir sonido.

También puedes servirlo con `python -m http.server 8000 --directory dist` y abrir `http://localhost:8000`.

## Diseño

- Altura total 12 m: cono 10,9 m y estrella 1,1 m.
- Base Ø 7,5 m; 64 líneas de 150 píxeles (9.600), más 96 de estrella.
- 9.696 nodos RGB / 29.088 canales. Datos a 12 V WS2811 compatibles según equipo final; el valor de tensión se refiere a alimentación, no a nivel lógico de data.
- Show de 180 s: Jingle Bells, Deck the Halls y We Wish You a Merry Christmas.
- 12 escenas de 15 s; 8 compases cada una. Cada canción ocupa 60 s.

## Archivos

- `dist/show.json`: pistas, BPM, escenas y fuentes musicales.
- `dist/geometry.json`: coordenadas en metros, eje Y hacia arriba.
- `dist/patch.csv` y `dist/patch.json`: patch de salidas propuesto.
- `dist/assets/navidad-lightman.mp3`: música del show, estéreo.
- `dist/assets/navidad-lightman.wav`: máster PCM16 estéreo, 22.050 Hz.
- `dist/assets/navidad-lightman.fseq`: show exportado a 40 fps, brillo 50 %, 180 s, FSEQ v2/zlib.
- `dist/proyecto.html`: propuesta imprimible y presupuesto estimado.
- `export-fseq.cjs`: exportador reproducible; solo requiere Node.js.
- `music-work/generate_music.py`: síntesis reproducible del arreglo instrumental (Python + numpy; FFmpeg para MP3).

## Patch y reproducción física

Universos Art-Net de base 0: 0–63 para líneas, 64 para estrella. Si tu interfaz numera desde 1, usa la columna `universe1` del CSV (1–65). Cada línea usa canales 1–450 de su universo; estrella usa 1–288. No se dividen líneas entre universos.

Los canales FSEQ son **contiguos**: línea 1 = 1–450, línea 2 = 451–900, etc.; estrella = 28.801–29.088. En el reproductor, configura las salidas según `startChannel` y `endChannel`, en vez de asumir 512 canales por universo. Los huecos de cada universo no se almacenan en el FSEQ.

PC propuesto: 10.10.10.10/24; ocho controladores de ocho salidas en .101–.108; controlador/receptor de estrella .109, salida 1. Son direcciones propuestas, no dispositivos detectados. Verificar capacidades de salida y protocolo de los equipos adquiridos. Los 65 universos funcionan en unicast y a 40 fps (25 ms por frame). Un switch central conecta reproductor y controladores. El navegador **no transmite Art-Net**; solo simula el show.

Importa el FSEQ y `navidad-lightman.mp3` en un reproductor compatible con FSEQ v2/zlib (por ejemplo, Falcon Player). Configura las 65 salidas con su dirección, universo, canal inicial y longitud del patch. Crea una playlist con ambos archivos emparejados. La compatibilidad y sincronía física requieren validación en el reproductor y los controladores reales antes de un evento. No se ha hecho prueba en hardware en este proyecto.

Regenerar FSEQ (brillo operativo opcional):

```text
node export-fseq.cjs dist/assets/navidad-lightman.fseq 0.5
```

El visor muestra brillo 70 % por defecto. El archivo de montaje se exporta al 50 % para revisión; son ajustes independientes.

## Dimensionamiento propuesto

Hipótesis conservadora de 0,60 W por nodo a blanco máximo: 5.817,6 W / 484,8 A a 12 V. Confirmar consumo y distribución real con la ficha del píxel elegido. Se prevén 16 fuentes de 600 W (9.600 W instalados), dos por cada uno de ocho gabinetes. Cada fuente alimenta cuatro líneas (360 W), sin unir positivos entre fuentes. La fuente 1 añade la estrella (417,6 W), dejando reserva. Referencia: ficha Mean Well LRS-600-12, 12 V / 50 A. Las fuentes no son por sí mismas equipos de intemperie: se alojan en gabinetes ventilados adecuados.

Proteger ramales de forma individual. Dimensionar fusibles, cable, inyección, puesta a tierra, tablero y acometida con un instalador según recorrido y condiciones de sede. La estrella puede necesitar señal diferencial/regenerada próxima a su ubicación. La estructura modular, contravientos y anclajes requieren cálculo específico de cargas, viento y suelo. La web representa el diseño, no sustituye ese cálculo.

## Presupuesto

Estimación interna en soles; no es oferta de proveedor ni cotización contractual. Incluye 5 % de repuestos (485 nodos: 10.181 nodos adquiridos), estructura, control, distribución, audio, programación, montaje y logística. Reserva 10 %, IGV de referencia 18 %. Los importes se detallan en `dist/proyecto.html`. Ajustar según ubicación, marcas, cálculo estructural y cotizaciones finales. No se autoriza ninguna compra con estos archivos.

## Licencias y fuentes

La música está sintetizada desde cero; no contiene grabaciones, samples ni voces de terceros. Se utilizan melodías tradicionales e históricas con un arreglo instrumental creado para este proyecto. Las fuentes se enlazan en `dist/show.json` y la web. Three.js mantiene su aviso MIT en `dist/assets/three.min.js`; la marca LIGHTMAN procede del visualizador anterior del usuario. Ver `LICENSES.txt`.

Referencias técnicas: formato FSEQ oficial de FalconChristmas/fpp; distribución de energía de Advatek; ficha oficial Mean Well LRS-600. Enlaces en la propuesta imprimible.
