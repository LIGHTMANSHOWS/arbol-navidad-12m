const fs=require('node:fs'),path=require('node:path'),E=require('./dist/engine.js');
const show=JSON.parse(fs.readFileSync('dist/show.json','utf8'));
fs.writeFileSync('dist/show-data.js','window.SHOW = '+JSON.stringify(show)+';\n');
const patch=E.patch();fs.writeFileSync('dist/patch.json',JSON.stringify(patch,null,2));
const cols=['model','strand','controller','ip','output','universe0','universe1','channelStart','channelEnd','pixels','firstPixel','lastPixel','startChannel','endChannel','direction'];
const csv='\uFEFF'+cols.join(',')+'\r\n'+patch.outputs.map(o=>cols.map(k=>'"'+String(o[k]).replace(/"/g,'""')+'"').join(',')).join('\r\n')+'\r\n';fs.writeFileSync('dist/patch.csv',csv);
fs.writeFileSync('dist/geometry.json',JSON.stringify({schema:'lightman/tree-geometry/v1',units:'meters',axes:'x horizontal; y vertical; z depth',spec:E.SPEC,points:E.geometry()},null,2));
const h=JSON.parse(fs.readFileSync('.openai/hosting.json'));h.static={directory:'dist'};fs.writeFileSync('.openai/hosting.json',JSON.stringify(h,null,2)+'\n');
console.log(JSON.stringify({duration:show.duration,pixels:E.geometry().length,outputs:patch.outputs.length,channels:patch.artnet.channels}));
