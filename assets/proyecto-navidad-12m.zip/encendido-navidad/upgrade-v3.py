from pathlib import Path
root=Path(__file__).resolve().parent
def change(s,old,new):
    if old not in s:raise RuntimeError('No se encontró el bloque: '+old[:100])
    return s.replace(old,new)
p=root/'dist/engine.js';s=p.read_text(encoding='utf-8')
s=change(s,"'use strict';","'use strict';\nconst FX=typeof module==='object'&&module.exports?require('./choreography.js'):TreeChoreography;")
s=change(s,'Cinta helicoidal blanca, inspirada en tu primera referencia.','Cinta helicoidal RGB con bordes independientes y cono interior opaco.')
s=change(s,'Líneas de luz, espirales y barridos de gran impacto.','Líneas de luz sobre un cono interior opaco.')
anchor='function addStar(points)'
s=change(s,anchor,"PALETTES.midnight=[[.015,.12,1],[.4,.025,.85],[.06,.65,1]];PALETTES.aurora=[[.02,.9,.7],[.15,.08,1],[.75,.02,.5]];\nconst EFFECTS=['intro','burst','spiral','ribbons','snow','waves','sparkle','rings','comet','fan','checker','finale',...FX.EFFECTS];\n"+anchor)
old="const f=i/1199,angle=f*Math.PI*2*12,y=.32+f*10.28,r=3.75*(1-y/10.9)+.045;for(let row=0;row<8;row++){points.push({x:Math.sin(angle)*r,y:Math.max(.02,y+(row/7-.5)*.5),z:Math.cos(angle)*r"
new="const f=i/1199,angle=f*Math.PI*2*12,y=.32+f*10.28;for(let row=0;row<8;row++){const yy=Math.max(.02,y+(row/7-.5)*.5),r=3.75*(1-yy/10.9)+.045;points.push({x:Math.sin(angle)*r,y:yy,z:Math.cos(angle)*r"
s=change(s,old,new)
s=change(s,'function lights(points,t,track,brightness=.85,option=1)', 'function lights(points,t,track,brightness=.85,option=1,edgeSettings={})')
s=change(s,'c=PALETTES.gold[0];gain=.025','c=pal[0];gain=.025')
s=change(s,"break;}default:c=pal[0];}","break;}default:{const frame=FX.pattern(cue.effect,p,pal,beat);c=frame.color;gain=frame.gain;}}")
s=change(s,"if(option===2&&cue.effect!=='intro'){if(p.feature==='edge'){c=mix(c,[1,1,1],.88);gain=Math.max(gain,.88);}else c=mix(c,[.75,.9,1],.32);}","if(option===2&&p.feature==='edge'&&cue.effect!=='intro'){const frame=FX.edge(p,cue,beat,PALETTES,edgeSettings);c=frame.color;gain=frame.gain;}")
s=change(s,"c=mix(c,PALETTES.multicolor[Math.floor(hash(i)*5)],.4)","c=mix(c,PALETTES.multicolor[Math.floor(hash(i)*5)],.08)")
s=change(s,'for(let j=0;j<3;j++)result[q++]=clamp(c[j]*gain*brightness*tail);','const edgeLevel=option===2&&p.feature===\'edge\'?(edgeSettings.brightness??1):1;for(let j=0;j<3;j++)result[q++]=clamp(c[j]*gain*brightness*tail*edgeLevel);')
s=change(s,'return {SPEC,OPTIONS,PALETTES,geometry','return {SPEC,OPTIONS,PALETTES,EFFECTS,geometry')
p.write_text(s,encoding='utf-8')

p=root/'dist/app.js';s=p.read_text(encoding='utf-8')
s=change(s,'selectionRevision=0;','selectionRevision=0;const edgeSettings={palette:null,brightness:1};')
s=change(s,"$('scene').dataset.tree=option;updateURL();syncUI();","$('scene').dataset.tree=option;$('edge-controls').hidden=option!==2;updateURL();syncUI();")
s=change(s,"$('brightness').oninput=", "$('edge-palette').onchange=()=>{edgeSettings.palette=$('edge-palette').value||null;};$('edge-brightness').oninput=()=>{edgeSettings.brightness=Number($('edge-brightness').value)/100;$('edge-brightness-out').textContent=Math.round(edgeSettings.brightness*100)+' %';};\n$('brightness').oninput=")
s=change(s,"if(option!==2){const inner=new THREE.Mesh(new THREE.ConeGeometry(3.61,10.86,64,1,true),new THREE.MeshBasicMaterial({color:option===3?0x0b2914:0x06170c,transparent:option!==3,opacity:option===3?1:.6,side:THREE.DoubleSide,depthWrite:option===3}));inner.position.y=5.43;treeGroup.add(inner);}","const inner=new THREE.Mesh(new THREE.ConeGeometry(option===3?3.61:3.70,10.9,128,1,false),new THREE.MeshBasicMaterial({color:option===3?0x0b2914:0x07170d,transparent:false,opacity:1,side:THREE.DoubleSide,depthTest:true,depthWrite:true}));inner.position.y=5.45;inner.name='solid-inner-cone';treeGroup.add(inner);$('scene').dataset.solidCone=String(!inner.material.transparent&&inner.material.opacity===1&&inner.material.depthWrite);$('scene').dataset.coneRadius=inner.geometry.parameters.radius;")
s=change(s,"const f=i/1199,a=f*Math.PI*2*12,y=.32+f*10.28,r=3.75*(1-y/10.9)+.045;verts.push(Math.sin(a)*r,y-.25,Math.cos(a)*r,Math.sin(a)*r,y+.25,Math.cos(a)*r);", "const f=i/1199,a=f*Math.PI*2*12,y=.32+f*10.28,r0=3.75*(1-(y-.25)/10.9)+.045,r1=3.75*(1-(y+.25)/10.9)+.045;verts.push(Math.sin(a)*r0,y-.25,Math.cos(a)*r0,Math.sin(a)*r1,y+.25,Math.cos(a)*r1);")
s=change(s,"color:0xc7ddff,transparent:true,opacity:.1","color:0x0b2414,transparent:true,opacity:.14")
s=change(s,"effect:option===2?'sparkle':option===3?'checker':'spiral',palette:option===2?'ice':option===3?'multicolor':'christmas'", "effect:track.visualTheme.previewEffect,palette:track.visualTheme.previewPalette,edgeEffect:track.cues[2].edgeEffect,edgePalette:track.cues[2].edgePalette,edgeSpeed:track.cues[2].edgeSpeed,edgeDirection:track.cues[2].edgeDirection")
s=change(s,'E.lights(points,t,displayTrack,brightness,option)','E.lights(points,t,displayTrack,brightness,option,edgeSettings)')
s=change(s,"modelMaterials.forEach(m=>m.opacity=preview?.1:t<track.ignitionAt?.01:.1);","modelMaterials.forEach(m=>m.opacity=.14);")
s=change(s,'18 escenas y un','18 escenas y un') if '18 escenas y un' in s else s
s=change(s,'Cada pista es un show independiente. Una preparación musical','Cada pista tiene su coreografía propia: Jingle Bells con campanas y caramelos, Deck the Halls con guirnaldas y fiesta, Carol of the Bells con auroras y cristales. Una preparación musical')
s=change(s,'Los tres FSEQ incluidos corresponden a la opción 1','Los FSEQ incluidos de las opciones 1 y 2 corresponden')
s=change(s,"<a class=\"button\" href=\"assets/sequences/'+t.id+'.fseq\" download>FSEQ opción 1 ↓</a>","<a class=\"button\" href=\"assets/sequences/'+t.id+'.fseq\" download>FSEQ opción 1 ↓</a><a class=\"button\" href=\"assets/sequences/'+t.id+'-option-2.fseq\" download>FSEQ opción 2 ↓</a>")
p.write_text(s,encoding='utf-8')

p=root/'dist/index.html';s=p.read_text(encoding='utf-8')
s=change(s,'con bordes blancos y destellos en toda la malla.','con bordes RGB que cambian de color independientemente de la malla.')
s=change(s,'<p class="quiet">La música y las luces usan el mismo reloj.', '<fieldset id="edge-controls" class="edge-controls" hidden><legend>Bordes de la espiral · Elemento independiente</legend><label>Paleta de los bordes<select id="edge-palette"><option value="">Seguir coreografía de la pista</option><option value="christmas">Rojo, verde y dorado</option><option value="gold">Dorado</option><option value="midnight">Azul y violeta</option><option value="aurora">Aurora</option><option value="multicolor">Multicolor</option></select></label><label>Brillo de los bordes <output id="edge-brightness-out">100 %</output><input type="range" id="edge-brightness" min="0" max="100" value="100"></label><p class="quiet">El borde superior y el inferior tienen animación propia. El control no modifica la malla del árbol.</p></fieldset><p class="quiet">La música y las luces usan el mismo reloj.')
s=change(s,'<script src="engine.js?v=2">','<script src="choreography.js?v=3"></script><script src="engine.js?v=3">')
s=s.replace('tracks-data.js?v=2','tracks-data.js?v=3').replace('app.js?v=2','app.js?v=3').replace('style.css?v=2','style.css?v=3')
p.write_text(s,encoding='utf-8')
print('Coreografías, bordes RGB e interior opaco actualizados')

