# LIGHTMAN · Encendido de Navidad · Versión 2

[Abrir la web pública](https://lightmanshows.github.io/arbol-navidad-12m/)

Tres diseños de árbol de 12 m y tres pistas navideñas **independientes**, con cuenta de encendido, golpe blanco, drops y finales. Cambia de árbol con Opción 1, Opción 2 y Opción 3; elige una canción y pulsa Iniciar encendido. Cada canción comienza en 00:00 y se descarga por separado.

## Música

| Pista | BPM | Duración | Golpe de encendido |
| --- | --- | --- | --- |
| Jingle Bells · Encendido | 144 | 120 s | 13,333 s |
| Deck the Halls · Fiesta | 160 | 108 s | 12 s |
| Carol of the Bells · Épico | 168 | 102,857 s | 11,429 s |

Cada pista tiene 18 escenas. Bombo dance, clap, cascabeles, bajo, arpegios, cuerdas y metales sintetizados desde cero. No hay samples, grabaciones de terceros ni letra inglesa de Carol of the Bells. Créditos y fuentes en `dist/tracks.json`.

## Diseños

- Opción 1, Píxel 360°: 64 líneas de 150 píxeles y estrella de 96.
- Opción 2, Espiral de luz: 12 vueltas helicoidales, ocho filas de malla y bordes blancos; interpretación de la primera foto del usuario.
- Opción 3, Bosque de Navidad: 7.680 nodos de fondo, 1.920 nodos en 16 copos y 96 en estrella; interpretación de la segunda foto.

Cada modelo digital tiene 9.696 nodos, 12 m de altura total y Ø 7,5 m de base. Esta equivalencia permite comparar y exportar el show. Mallas, copos, estructura, cableado y cantidades finales requieren diseño de fabricación propio. El presupuesto de la web es una base referencial de la opción 1, no una oferta de proveedor para las tres variantes.

## Abrir sin instalación

Abre `dist/index.html` en un navegador con WebGL, o ejecuta `python -m http.server 8000 --directory dist`. El audio y las bibliotecas están incluidos. Las fuentes externas tienen respaldo local de sistema. Un navegador requiere un clic del usuario para iniciar audio.

El enlace se puede compartir con `?tree=2&track=carol` para abrir una combinación concreta. Cambiar de canción reinicia su propio archivo; no es un medley. Pausa y búsqueda usan el reloj del audio para conservar sincronización.

## Archivos

- `dist/assets/audio/`: tres MP3 y tres másteres WAV (los WAV se descargan por separado en el paquete web; incluidos en el ZIP del chat).
- `dist/tracks.json`: tres pistas con BPM, tiempo de encendido y cues.
- `dist/geometry-option-1.json` hasta `-3.json`: coordenadas y orden de píxeles.
- `dist/patch-option-1.csv` hasta `-3.csv` y `.json`: bloques y salidas propuestos.
- `dist/assets/sequences/jingle.fseq`, `deck.fseq`, `carol.fseq`: exportaciones para opción 1, 50 % de brillo, 40 fps, FSEQ v2/zlib.
- `dist/proyecto.html`: propuesta imprimible actualizada.
- `music-work/generate_energetic_tracks.py`: síntesis nueva (Python + numpy + FFmpeg). Requiere también `generate_music.py` para leer las listas melódicas mediante AST; no ejecuta el medley anterior.

## Exportar otras combinaciones

Solo se necesita Node.js; no requiere dependencias npm:

```text
node export-fseq.cjs all 1 0.5
node export-fseq.cjs carol 2 0.5
node export-fseq.cjs deck 3 0.5
```

Los archivos de opciones 2 y 3 se guardan como `carol-option-2.fseq`, etc. Empareja cada FSEQ con el MP3 original de su pista, cuyo nombre se incluye en el header. La exportación usa cuadros de 25 ms: Carol tiene 4.115 frames (102,875 s), menos de un frame extra respecto del audio. El último frame se guarda negro.

## Patch

29.088 canales RGB contiguos. 64 bloques de 150 nodos / 450 canales por universo; estrella con 96 nodos / 288 canales. Universos Art-Net base 0: 0–64; columna alternativa base 1: 1–65. Canal global 1–450 para bloque 1, 451–900 para bloque 2 y así sucesivamente; estrella 28.801–29.088. Configura el reproductor con `startChannel`, `endChannel` y longitud del CSV, sin asumir 512 canales almacenados por universo.

PC propuesto 10.10.10.10/24; controladores de 8 salidas .101–.108; estrella .109. Son direcciones propuestas, no equipos detectados. Las opciones 2 y 3 siguen el orden geométrico del JSON; validar que coincida con las conexiones reales. El navegador solo simula y no emite Art-Net. La ejecución física requiere ensayo con el reproductor y los controladores adquiridos.

Potencia de cálculo 0,60 W/nodo a blanco total: 5.817,6 W. 16 fuentes de 600 W / 12 V previstas. Confirmar consumo del lote, inyección, fusibles, cable, tierra y tablero con el instalador; no unir positivos entre fuentes. La estructura y los anclajes necesitan cálculo específico de viento, carga y suelo.

## Créditos

Audio y arreglos nuevos para LIGHTMAN, sintetizados desde cero. Las fuentes musicales están en `tracks.json`. Three.js MIT; marca LIGHTMAN procedente del proyecto del usuario. Fotos de referencia proporcionadas por el usuario, con fines de comparación del diseño. Documentación y métricas musicales en `music-work/ENERGETIC-TRACKS.md` y `energetic-verification.json`.
