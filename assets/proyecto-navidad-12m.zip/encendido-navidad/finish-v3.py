from pathlib import Path
root=Path(__file__).resolve().parent
def edit(name,replacements):
 p=root/name;s=p.read_text(encoding='utf-8')
 for old,new in replacements:
  assert old in s,(name,old)
  s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')
edit('dist/choreography.js',[("side=p.pixel%8===0?0:.5","side=(p.strand*150+p.pixel)%8===0?0:.5")])
edit('dist/app.js',[("['Encendido dance · 144 BPM','Fiesta navideña · 160 BPM','Encendido épico · 168 BPM'][i]","t.visualTheme.theme+' · '+t.bpm+' BPM'"),('Los FSEQ incluidos de las opciones 1 y 2 corresponden, 50 % de brillo y 40 fps. El script de exportación permite generar las tres pistas para las opciones 2 y 3.','Hay tres FSEQ por diseño para las opciones 1 y 2: 50 % de brillo y 40 fps, con sus coreografías y bordes independientes. El exportador también permite generar la opción 3.')])
edit('prepare.cjs',[("independent-shows/v2","independent-shows/v3"),("tree-geometry/v2","tree-geometry/v3")])
p=root/'dist/style.css';p.write_text(p.read_text(encoding='utf-8')+'\n.edge-controls{border:1px solid #d3b77b55;border-radius:5px;padding:0 18px 12px;margin-top:26px}.edge-controls[hidden]{display:none}.edge-controls legend{font-size:12px;color:var(--gold);padding:0 8px}.edge-controls select{display:block;width:100%;margin-top:12px;padding:12px;background:#0a1a12;color:var(--text);border:1px solid #63846d;border-radius:4px;font:inherit}\n',encoding='utf-8')
edit('build-package.py',[
 ('V2<br>','V3<br>'),('Versión 2 ·','Versión 3 ·'),('navidad-v2.zip','navidad-v3.zip'),
 ('Barridos, espirales y gráficos de color.','Barridos, espirales y gráficos de color sobre un cono interior opaco.'),
 ('con malla luminosa y bordes blancos. La estructura queda abierta entre las bandas.','con malla luminosa y bordes RGB independientes. Un cono interior sólido oculta las luces del lado opuesto.'),
 ('Los efectos incluyen espirales rápidas, cometas, abanicos, ondas, cintas, destellos y finales de alta energía.','Jingle Bells: campanas, caramelos y regalos. Deck the Halls: guirnaldas, rombos, cintas y celebración multicolor. Carol of the Bells: auroras, columnas, cristales y meteoros. Los bordes de la espiral siguen una animación y paleta independientes.'),
 ('y tres FSEQ de la opción 1.','y seis FSEQ para las opciones 1 y 2.'),
 ("(not masters and p.suffix=='.wav')","(not masters and (p.suffix=='.wav' or p.name.endswith('-option-2.fseq')))"),
 ("'upgrade-page.py']","'upgrade-page.py','upgrade-v3.py','finish-v3.py']")])
edit('README.md',[
 ('Versión 2','Versión 3'),
 ('Cada pista tiene 18 escenas.','Cada pista tiene 18 escenas con coreografía propia: Jingle Bells usa campanas y caramelos; Deck the Halls, guirnaldas y rombos; Carol of the Bells, auroras, cristales y meteoros.'),
 ('bordes blancos;','bordes RGB independientes;'),
 ('Cada modelo digital tiene','Las opciones 1 y 2 incorporan un cono interior sólido y opaco que oculta los LEDs del lado opuesto. En la opción 2, el menú Ajustes permite cambiar por separado la paleta y el brillo de los bordes.\n\nCada modelo digital tiene'),
 ('- `dist/proyecto.html`:','- `dist/assets/sequences/*-option-2.fseq`: tres exportaciones con bordes RGB independientes para opción 2 (incluidas en el ZIP completo y descargables por separado en la web).\n- `dist/choreography.js` y `music-work/choreography.py`: efectos visuales y escenas propios de cada pista.\n- `dist/proyecto.html`:')])
print('Documentación y controles v3 preparados')
