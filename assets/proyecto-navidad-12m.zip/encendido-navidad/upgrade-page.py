from pathlib import Path
import json
root=Path(__file__).resolve().parent
p=root/'dist/index.html';s=p.read_text(encoding='utf-8')
s=s.replace('<title>LIGHTMAN · La Navidad cobra vida</title>','<title>LIGHTMAN · Encendido de Navidad · 3 árboles</title>')
s=s.replace('Un espectáculo de 9.696 píxeles, música y color, diseñado por LIGHTMAN.','Tres diseños de árbol de 12 m y tres shows musicales independientes para un encendido espectacular.')
s=s.replace('NAVIDAD · EDICIÓN LIGHTMAN','EL GRAN ENCENDIDO · LIGHTMAN')
s=s.replace('<h1>La Navidad<br>cobra <em>vida.</em></h1>','<h1>Que empiece<br>la <em>Navidad.</em></h1>')
s=s.replace('Doce metros de luz.<br>Un espectáculo que se siente.','Tres diseños. Tres shows.<br>Un encendido inolvidable.')
s=s.replace('<b>03:00</b><span>SHOW MUSICAL</span>','<b>3</b><span>PISTAS INDEPENDIENTES</span>')
if 'id="tree-options"' not in s:
    s=s.replace('<button class="hero-play"', '<div class="tree-picker"><span>ELIGE TU ÁRBOL</span><div id="tree-options" role="group" aria-label="Diseño de árbol"><button data-tree="1" class="active" aria-pressed="true">Opción 1<small>Píxel 360°</small></button><button data-tree="2" aria-pressed="false">Opción 2<small>Espiral de luz</small></button><button data-tree="3" aria-pressed="false">Opción 3<small>Con copos</small></button></div><p id="tree-description">Líneas de luz y barridos envolventes.</p></div><button class="hero-play"')
s=s.replace('Vivir el espectáculo<small>Luces + música navideña','Iniciar encendido<small>Cuenta de entrada + gran encendido')
s=s.replace('Activa el sonido para disfrutar la experiencia.','Cada pista se reproduce por separado. Activa el sonido.')
if 'id="ignition-overlay"' not in s:
    s=s.replace('<div class="dimension">','<div id="ignition-overlay" class="ignition-overlay" aria-live="off" hidden><span id="ignition-number"></span><small id="ignition-label">EL MOMENTO SE ACERCA</small></div><div class="dimension">')
s=s.replace('SHOW NAVIDEÑO</small>','PISTA INDEPENDIENTE</small>')
s=s.replace('<div class="timeline-segments"><span>01 · Campanas</span><span>02 · La celebración</span><span>03 · Feliz Navidad</span></div>','<div class="timeline-segments"><span>PREPARACIÓN</span><span>ENCENDIDO + CELEBRACIÓN</span><span>GRAN FINAL</span></div>')
s=s.replace('<div class="chapters" id="chapters"></div>','<div class="music-intro"><span>TRES FORMAS DE ENCENDER LA NAVIDAD</span><small>Elige una pista · Reproducción y descarga independientes</small></div><div class="chapters" id="chapters"></div><div class="cue-strip" id="cue-strip" aria-label="Escenas de la pista"></div>')
s=s.replace('Una pieza central para plazas, centros comerciales y celebraciones de ciudad. Las luces envuelven el árbol en espirales, nieve y cintas de color; la música une cada escena en una sola historia.','El primer golpe de luz debe hacer que todos miren hacia arriba. Por eso cada pista tiene una preparación, un gran encendido y una celebración llena de espirales, cometas, abanicos y color. Compara los tres diseños con cualquiera de las canciones.')
s=s.replace('<b>64</b>líneas de luz','<b>3</b>diseños a elegir')
s=s.replace('</section>\n<footer>','</section>\n<section class="design-gallery" aria-label="Diseños y referencias"><div class="gallery-heading"><p class="eyebrow">TRES SILUETAS · UN GRAN ENCENDIDO</p><h2>Elige el árbol de tu celebración.</h2></div><div class="design-cards"><button data-design-card="1"><div class="design-art pixel-art"><i></i><b>✧</b></div><span class="design-number">OPCIÓN 01</span><strong>Píxel 360°</strong><p>La luz se mueve por cada línea del árbol. Ideal para secuencias gráficas y barridos de color.</p><small>VER EN 3D ↗</small></button><button data-design-card="2"><img src="assets/references/espiral-referencia.png" alt="Referencia del árbol en espiral blanca proporcionada por el usuario"><span class="design-number">OPCIÓN 02 · TU REFERENCIA</span><strong>Espiral de luz</strong><p>Una gran cinta luminosa se eleva hasta la estrella, con bordes blancos y destellos en toda la malla.</p><small>VER EN 3D ↗</small></button><button data-design-card="3"><img src="assets/references/copos-referencia.png" alt="Referencia del árbol multicolor con copos proporcionada por el usuario"><span class="design-number">OPCIÓN 03 · TU REFERENCIA</span><strong>Bosque de Navidad</strong><p>Superficie de píxeles multicolor y grandes copos luminosos. Un árbol tradicional con un show moderno.</p><small>VER EN 3D ↗</small></button></div><p class="reference-note">Fotos de referencia proporcionadas por ti. Los modelos 3D son interpretaciones para comparar el diseño; no representan una instalación ejecutada.</p></section>\n<footer>')
s=s.replace('src="assets/navidad-lightman.mp3"','src="assets/audio/jingle-encendido.mp3"')
s=s.replace('70 %</output>','85 %</output>').replace('max="100" value="70"','max="100" value="85"')
s=s.replace('Tres clásicos · Una historia','Tres pistas · Tres encendidos')
start=s.index('<dialog id="credits">');end=s.index('</dialog>',start)+len('</dialog>')
s=s[:start]+'''<dialog id="credits"><div class="dialog-head"><div><p class="eyebrow">TRES PISTAS · TRES ENCENDIDOS</p><h2>Navidad con más energía.</h2></div><button class="close" aria-label="Cerrar">×</button></div><p>Tres arreglos instrumentales independientes, creados para este proyecto. Bombo dance, clap, cascabeles, bajo, arpegios, cuerdas y metales se unen a las melodías de Jingle Bells, Deck the Halls y Carol of the Bells / Shchedryk.</p><p>Las pistas son sintetizadas desde cero; no utilizan grabaciones comerciales, samples ni voces de terceros. La última pista utiliza el motivo instrumental de Shchedryk, sin la letra inglesa moderna.</p><div id="credit-links"></div><div id="music-downloads"></div><p class="quiet">Motor 3D: Three.js, licencia MIT. Fotos de referencia aportadas por el usuario.</p></dialog>'''+s[end:]
s=s.replace('src="show-data.js"','src="tracks-data.js"')
p.write_text(s,encoding='utf-8')
data=json.loads((root/'dist/tracks.json').read_text(encoding='utf-8'))
(root/'dist/tracks-data.js').write_text('window.TRACKS = '+json.dumps(data,ensure_ascii=False)+';\n',encoding='utf-8')
