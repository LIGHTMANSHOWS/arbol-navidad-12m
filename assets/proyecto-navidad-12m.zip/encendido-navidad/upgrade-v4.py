from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'dist/engine.js';s=p.read_text(encoding='utf-8')
start=s.index('const levels=[{h:.14,count:6}')
end=s.index('\nelse{for(let s=0;s<64;s++)',start)
block="""// Snowflakes follow the slope and curvature of the cone, 3.5 cm above its surface.
const levels=[{h:.10,count:11},{h:.26,count:9},{h:.42,count:8},{h:.58,count:6},{h:.74,count:4},{h:.89,count:2}],slope=3.75/10.9,verticalScale=1/Math.sqrt(1+slope*slope);let ornament=0;
for(let levelIndex=0;levelIndex<levels.length;levelIndex++){const level=levels[levelIndex];for(let j=0;j<level.count;j++){
const a=fract((j+(levelIndex%2?.5:0))/level.count+.035*levelIndex),angle=a*Math.PI*2,centerY=level.h*10.9,centerRadius=3.75*(1-level.h)+.035,center={x:Math.sin(angle)*centerRadius,y:centerY,z:Math.cos(angle)*centerRadius},radius=.48*(1-level.h*.35);
for(let spoke=0;spoke<6;spoke++){const aa=Math.PI/2+spoke*Math.PI/3;for(let k=0;k<8;k++){let u,v;
if(k<4){const d=(k+1)/4*radius;u=Math.cos(aa)*d;v=Math.sin(aa)*d;}
else{const sign=k<6?1:-1,d=((k%2)+1)/2*radius*.36;u=Math.cos(aa)*radius*.5+Math.cos(aa+sign*Math.PI/3)*d;v=Math.sin(aa)*radius*.5+Math.sin(aa+sign*Math.PI/3)*d;}
const y=centerY+v*verticalScale,theta=angle+u/centerRadius,r=3.75*(1-y/10.9)+.035,idx=points.length;
points.push({x:Math.sin(theta)*r,y,z:Math.cos(theta)*r,strand:Math.floor(idx/150),pixel:idx%150,h:y/10.9,a:fract(theta/(Math.PI*2)),star:false,feature:'ornament',ornament,...(spoke===0&&k===0?{ornamentCenter:center}:{} )});
}}ornament++;}}}
"""
s=s[:start]+block.rstrip()+s[end:]
s=s.replace('Árbol lleno de color con copos luminosos, inspirado en tu segunda referencia.','40 copos luminosos inclinados y adheridos a la superficie del árbol.')
p.write_text(s,encoding='utf-8')
p=root/'dist/app.js';s=p.read_text(encoding='utf-8')
start=s.index('if(option===3){const edges=[];')
end=s.index('\nif(option===2){const verts=',start)
block="""if(option===3){const edges=[];const segment=(a,b)=>edges.push(a.x,a.y,a.z,b.x,b.y,b.z);
for(let base=7680;base<9600;base+=48){const center=points[base].ornamentCenter;for(let spoke=0;spoke<6;spoke++){const k=base+spoke*8;segment(center,points[k]);for(let j=1;j<4;j++)segment(points[k+j-1],points[k+j]);for(const wing of [4,6]){segment(points[k+1],points[k+wing]);segment(points[k+wing],points[k+wing+1]);}}}
const og=new THREE.BufferGeometry();og.setAttribute('position',new THREE.Float32BufferAttribute(edges,3));ornamentMaterial=new THREE.LineBasicMaterial({color:0xc3f4ff,transparent:true,opacity:.95,depthWrite:false});treeGroup.add(new THREE.LineSegments(og,ornamentMaterial));}
$('scene').dataset.ornamentCount=option===3?'40':'0';
"""
s=s[:start]+block.rstrip()+s[end:]
s=s.replace('option===3?3.61:3.70','option===3?3.74:3.70').replace('1.920 en 16 copos','1.920 en 40 copos inclinados y adheridos al cono')
p.write_text(s,encoding='utf-8')
for name in ['README.md','build-package.py','dist/index.html']:
 p=root/name;s=p.read_text(encoding='utf-8')
 s=s.replace('16 copos','40 copos').replace('dieciséis copos','cuarenta copos').replace('grandes copos luminosos.','40 copos luminosos inclinados y adheridos al árbol.').replace('Versión 3','Versión 4').replace('V3<br>','V4<br>').replace('navidad-v3.zip','navidad-v4.zip')
 if name=='README.md':s=s.replace('1.920 nodos en 40 copos','1.920 nodos en 40 copos inclinados y adaptados a la superficie')
 if name=='build-package.py':s=s.replace("'finish-v3.py']","'finish-v3.py','upgrade-v4.py']")
 if name=='dist/index.html':s=s.replace('?v=3','?v=4')
 p.write_text(s,encoding='utf-8')
print('Opción 3: 40 copos adheridos e inclinados')
