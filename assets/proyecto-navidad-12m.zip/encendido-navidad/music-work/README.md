# Música del árbol LIGHTMAN de 12 metros

Un solo medley instrumental, compuesto y sintetizado para esta previsualización a partir de tres melodías navideñas conocidas. Se programaron nuevas voces, armonización, bajo, arpegios, percusión, paneo y reverberación. No se descargaron ni se incorporaron grabaciones, muestras o arreglos de terceros. No incluye letras ni voces.

| Sección | Inicio | Fin | Tempo | Compás | Compases |
|---|---:|---:|---:|---|---:|
| Jingle Bells | 0 s | 60 s | 128 BPM | 4/4 | 32 |
| Deck the Halls | 60 s | 120 s | 128 BPM | 4/4 | 32 |
| We Wish You a Merry Christmas | 120 s | 180 s | 96 BPM | 3/4 | 32 |

Las 12 escenas duran 15 segundos cada una: exactamente 8 compases al tempo de cada sección. El archivo `dist/show.json` define sus límites, nombres, efectos, colores y referencias de investigación. La reproducción web debe usar `audio.currentTime` como reloj de todas las escenas y el cambio de compás en 120 s. La pista termina con una atenuación de 2 s.

## Archivos

- `dist/assets/navidad-lightman.mp3`: estéreo, 44.1 kHz, 128 kb/s, 2,881,035 bytes, duración 180.000 s. Activo recomendado para la web.
- `dist/assets/navidad-lightman.wav`: PCM estéreo de 16 bits, 22.05 kHz, 15,876,044 bytes, duración 180.000 s. Máster reproducible sin compresión con pérdida.
- `generate_music.py`: fuente completa. Requiere Python 3, NumPy y FFmpeg en PATH. Ejecutar `python generate_music.py` desde esta carpeta.
- `verification.json`: métricas del archivo generado.

## Verificación

Se verificaron los 48 compases de las melodías base antes de repetirlos, los límites de cada sección, el número exacto de muestras, la decodificación MP3 y su duración con FFprobe. WAV: pico -0.819 dBFS, RMS -14.802 dBFS, cero muestras saturadas. Todas las escenas son contiguas y cubren 0–180 s. Es una instrumentación electrónica de campanas/celesta y pads, con bajo y percusión suave; no se presenta como una grabación de orquesta o de cantantes.

## Investigación y créditos

- **Jingle Bells**, James Lord Pierpont: [edición de The One Horse Open Sleigh, 1857, Library of Congress](https://www.loc.gov/item/2023812429/). El catálogo histórico identifica autor y fecha.
- **Deck the Halls / Nos Galan**, melodía tradicional galesa: [digitalización de la edición original de Welsh Melodies, volumen 2, 1862](https://commons.wikimedia.org/wiki/File:Original_printed_version_of_Deck_the_Hall_with_Boughs_of_Holly.jpg). La página documenta la procedencia del ejemplar escaneado de la familia Oliphant. La grabación usa solo una melodía instrumental con nueva armonización.
- **We Wish You a Merry Christmas**, melodía tradicional inglesa: [ficha publicada por el arreglista David M. Sampson en IMSLP](https://imslp.org/wiki/Christmas_Songs_for_3_Guitars_(Sampson,_David_M.)). Se usó únicamente para identificar la procedencia tradicional, sin copiar su partitura, grabación ni arreglo.

Arreglo instrumental y grabación sintetizada: generados para **LIGHTMAN · La magia de Navidad**, 2026. Las referencias son créditos de investigación y no indican que las grabaciones de esos catálogos estén incluidas en este proyecto.
