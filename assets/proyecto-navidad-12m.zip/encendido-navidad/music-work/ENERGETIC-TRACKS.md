# Tres encendidos musicales independientes

Esta actualización crea tres canciones completas e independientes para el mismo árbol LIGHTMAN de 12 metros. Se escribieron arreglos e instrumentos nuevos: batería dance con bombo en cada negra, snare/clap en 2 y 4, hats y cascabeles, bajo, arpegios rápidos, cuerdas, metales, campanas, risers, fanfarrias y limitación suave para un máster enérgico. No se aceleró el medley anterior.

| Pista | Tempo | Compás | Duración exacta | Encendido |
|---|---:|---|---:|---:|
| Jingle Bells · Encendido | 144 BPM | 4/4 | 120 s | 13.333333333 s |
| Deck the Halls · Fiesta | 160 BPM | 4/4 | 108 s | 12 s |
| Carol of the Bells · Épico | 168 BPM | 4/4 | 102.857142857 s | 11.428571429 s |

Cada pista tiene 72 compases y 18 escenas. Compases 0–8: introducción creciente y build. El primer beat del compás 8 dispara el encendido con un golpe de campanas, crash y metales, coordinado con `burst` blanco. Luego entra el primer drop en espiral. Hay un puente en el compás 24, un segundo build en el 32, otro drop en el 40, una pausa dramática en el 56 y un gran final en el 64. La atenuación final dura exactamente 2 segundos.

`dist/tracks.json` es la fuente de tiempos de la web. El reloj recomendado para efectos es `audio.currentTime`; cada pista se reinicia desde cero. El efecto `burst` debe mostrar un golpe blanco durante una negra desde `ignitionAt` y enlazar con el cue `spiral`. Los BPM y el compás permiten pulsos regulares entre cambios de escenas. El tema Shchedryk se transforma musicalmente a 4/4 como arreglo dance propio.

## Reproducción del activo

Ejecutar desde esta carpeta:

```powershell
python generate_energetic_tracks.py
```

Requiere Python 3 con NumPy, FFmpeg y FFprobe en PATH. La fuente lee las listas literales `JINGLE` y `DECK` de `generate_music.py` con AST; **no ejecuta ese archivo** ni escribe el medley previo. Los generadores deben mantenerse juntos para reproducir las tres pistas. Los únicos destinos de escritura son `dist/assets/audio/`, `dist/tracks.json` y `music-work/energetic-verification.json`.

## Archivos de entrega

- `assets/audio/jingle-encendido.mp3` y `.wav`
- `assets/audio/deck-fiesta.mp3` y `.wav`
- `assets/audio/carol-epico.mp3` y `.wav`

WAV máster: PCM16, 22.05 kHz, estéreo; tamaños 10.58, 9.53 y 9.07 MB. MP3 para la web: 44.1 kHz, estéreo, 160 kb/s; tamaños 2.40, 2.16 y 2.06 MB.

## Verificación objetiva

Se comprobó la duración objetivo, número de muestras WAV, duración del contenedor MP3 y número de muestras tras decodificar cada MP3 a PCM flotante. Las tres duraciones coinciden con sus 72 compases; Carol coincide dentro del redondeo de seis decimales de FFprobe. Los cues son contiguos, incluyen exactamente un beat de encendido y cubren cada pista completa.

| Pista | Pico WAV | RMS WAV | Pico MP3 decodificado | Muestras saturadas |
|---|---:|---:|---:|---:|
| Jingle | -1.94 dBFS | -11.51 dBFS | -1.26 dBFS | 0 |
| Deck | -1.94 dBFS | -10.94 dBFS | -1.18 dBFS | 0 |
| Carol | -1.94 dBFS | -10.99 dBFS | -1.26 dBFS | 0 |

La amplitud RMS sube aproximadamente tres veces entre introducción y primer drop. También se verificó que el MP3 decodificado en formato flotante no supera 0 dBFS; no se ocultaron posibles saturaciones convirtiendo primero a enteros. Las métricas detalladas están en `energetic-verification.json`. Son instrumentos sintetizados, sin voces ni muestras de instrumentos reales.

## Fuentes y créditos

**Jingle Bells / The One Horse Open Sleigh**, James Lord Pierpont (1857): [catálogo y edición histórica de Library of Congress](https://www.loc.gov/item/2023812429/).

**Deck the Halls / Nos Galan**, melodía tradicional galesa: [facsímil de Welsh Melodies, volumen 2, edición de 1862](https://commons.wikimedia.org/wiki/File:Original_printed_version_of_Deck_the_Hall_with_Boughs_of_Holly.jpg). No se reutilizó una grabación ni una armonización comercial.

**Shchedryk**, motivo ucraniano asociado a Mykola Leontovych: [Ukrainian Institute: facsímil del manuscrito y estreno del 29 de diciembre de 1916](https://ui.org.ua/en/news-en/the-notes-of-shchedryk-are-now-displayed-on-one-of-the-walls-of-new-yorks-carnegie-hall/). La fuente confirma el manuscrito, su custodia en la Biblioteca Nacional Vernadsky y el origen folklórico del motivo. La fecha 1916 se documenta como manuscrito/estreno; no se presenta como fecha de publicación editorial. Esta pista usa el motivo instrumental con nueva armonización y una estructura dance propia. No incluye la letra inglesa moderna de Carol of the Bells.

Arreglos, síntesis y grabaciones nuevos para LIGHTMAN, 2026. No se descargaron ni incorporaron samples ni grabaciones de terceros.
