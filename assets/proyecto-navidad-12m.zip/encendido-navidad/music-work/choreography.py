"""Distinct, beat-aligned visual shows; leaves the three audio files unchanged."""
from pathlib import Path
import json

# Each entry: scene name, surface effect/palette, independent edge effect/palette.
PROFILES={
'jingle':{
 'theme':'Campanas y caramelos', 'summary':'Rebotes de campanas, bastones de caramelo, regalos y un final rojiblanco.',
 'previewEffect':'candyChase','previewPalette':'candy',
 'scenes':[
 ('Campanas a lo lejos · preparación','intro','gold','chase','christmas'),
 ('¡Jingle Bells! · encendido','burst','ice','alternate','christmas'),
 ('Bastones de caramelo · primera fiesta','candyChase','candy','chase','christmas'),
 ('Campanas que rebotan','bellBounce','gold','echo','gold'),
 ('Paseo en trineo','sleigh','candy','chase','christmas'),
 ('Regalos bajo el árbol','giftBoxes','christmas','alternate','gold'),
 ('Rueda de menta','peppermint','candy','chase','christmas'),
 ('Repique de campanas','bellPeal','gold','echo','candy'),
 ('Nieve del camino · respiro','snow','ice','wave','ice'),
 ('Llegan los cascabeles · subida','bellBounce','candy','chase','gold'),
 ('Confeti de Navidad · segundo drop','confetti','multicolor','alternate','christmas'),
 ('El trineo acelera','sleigh','gold','chase','candy'),
 ('Regalos que se abren','giftBoxes','candy','alternate','christmas'),
 ('Caramelos en espiral','candyChase','christmas','chase','gold'),
 ('Una campana dorada','bellPeal','gold','echo','christmas'),
 ('La última vuelta de menta','peppermint','candy','wave','gold'),
 ('Gran fiesta rojiblanca','jingleFinale','candy','chase','christmas'),
 ('Campanada final LIGHTMAN','jingleFinale','gold','echo','christmas') ]},
'deck':{
 'theme':'Guirnaldas y celebración', 'summary':'Guirnaldas verdes y doradas, rombos, cintas entrelazadas y fiesta multicolor.',
 'previewEffect':'garland','previewPalette':'christmas',
 'scenes':[
 ('Las guirnaldas despiertan · preparación','intro','christmas','wave','gold'),
 ('¡Deck the Halls! · encendido','burst','ice','alternate','gold'),
 ('Guirnaldas de gala','garland','christmas','wave','gold'),
 ('Cintas que se entrelazan','weave','christmas','chase','candy'),
 ('Baile de abanicos','fanDance','gold','alternate','christmas'),
 ('Rombos sobre el árbol','diamonds','christmas','echo','gold'),
 ('Carrusel de celebración','carousel','multicolor','chase','christmas'),
 ('Olas de fiesta','partyWaves','candy','wave','gold'),
 ('El salón respira · puente','garland','gold','wave','christmas'),
 ('El lazo se cierra · subida','weave','christmas','chase','gold'),
 ('Carnaval de luces · segundo drop','rainbowChase','multicolor','chase','multicolor'),
 ('Abanicos de la gran fiesta','fanDance','christmas','alternate','gold'),
 ('Rombos y diamantes','diamonds','gold','echo','christmas'),
 ('Carrusel verde y rojo','carousel','christmas','chase','candy'),
 ('Olas en el jardín','partyWaves','christmas','wave','gold'),
 ('Guirnalda de despedida','garland','gold','echo','christmas'),
 ('La plaza se viste de color','deckFinale','multicolor','chase','gold'),
 ('Final de gala LIGHTMAN','deckFinale','christmas','alternate','gold') ]},
'carol':{
 'theme':'Catedral de hielo', 'summary':'Columnas azules, auroras, cristales, meteoros y una explosión azul-dorada.',
 'previewEffect':'aurora','previewPalette':'aurora',
 'scenes':[
 ('Silencio en la catedral · preparación','intro','midnight','wave','aurora'),
 ('¡Carol of the Bells! · encendido','burst','ice','echo','gold'),
 ('Órgano de luz','cathedral','midnight','echo','ice'),
 ('Aurora sobre la plaza','aurora','aurora','wave','midnight'),
 ('El vórtice despierta','vortex','midnight','chase','aurora'),
 ('Lluvia de meteoros','meteorStorm','ice','chase','midnight'),
 ('Cristales de invierno','iceCrystal','ice','echo','aurora'),
 ('Pulso del gran órgano','organPulse','midnight','alternate','gold'),
 ('La aurora contiene el aire · puente','aurora','aurora','wave','ice'),
 ('El vórtice se concentra · subida','vortex','midnight','chase','gold'),
 ('Supernova · segundo drop','nova','gold','echo','midnight'),
 ('Meteoros sobre la catedral','meteorStorm','aurora','chase','ice'),
 ('Cristal azul y oro','iceCrystal','gold','echo','midnight'),
 ('Columnas del cielo','cathedral','ice','wave','gold'),
 ('La última aurora','aurora','aurora','wave','midnight'),
 ('El órgano llama al final','organPulse','gold','alternate','ice'),
 ('El cielo se abre','carolFinale','midnight','chase','gold'),
 ('Apoteosis azul y dorada LIGHTMAN','carolFinale','gold','echo','ice') ]}}

def apply_library(data):
    for track in data['tracks']:
        profile=PROFILES[track['id']]
        assert len(track['cues'])==len(profile['scenes'])
        track['visualTheme']={k:v for k,v in profile.items() if k!='scenes'}
        for i,(cue,config) in enumerate(zip(track['cues'],profile['scenes'])):
            name,effect,palette,edgeEffect,edgePalette=config
            cue.update(name=name,effect=effect,palette=palette,edgeEffect=edgeEffect,edgePalette=edgePalette,
                       edgeSpeed=[1.1,.85,1.35][['jingle','deck','carol'].index(track['id'])],
                       edgeDirection=-1 if track['id']=='carol' else 1)
    data['schema']='lightman/independent-choreographies/v3'
    return data

if __name__=='__main__':
    target=Path(__file__).resolve().parent.parent/'dist/tracks.json'
    data=apply_library(json.loads(target.read_text(encoding='utf-8')))
    target.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({t['id']:t['visualTheme']['theme'] for t in data['tracks']},ensure_ascii=False))
