"""Three independent 72-bar electro-orchestral Christmas ignition shows.
Original synthesis and arrangement. Python + numpy; ffmpeg and ffprobe in PATH.
This script only writes dist/assets/audio, dist/tracks.json and music-work metrics.
"""
from pathlib import Path
import ast, json, math, subprocess, wave
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'dist'/'assets'/'audio'
OUT.mkdir(parents=True,exist_ok=True)
SR=22050

# Import the explicitly transcribed traditional melodies WITHOUT executing the old
# generator, which would overwrite the original medley and its show metadata.
tree=ast.parse((ROOT/'music-work'/'generate_music.py').read_text(encoding='utf-8'))
melodies={}
for node in tree.body:
    if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name):
        if node.targets[0].id in ['JINGLE','DECK']:
            melodies[node.targets[0].id]=ast.literal_eval(node.value)

def midi(n):
    if isinstance(n,(int,np.integer)):return int(n)
    return 12*(int(n[-1])+1)+{'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[n[0]]+('#' in n)-('b' in n)

CHORDS={'C':(48,52,55),'F':(48,53,57),'G':(47,50,55),'Am':(45,48,52),
        'Dm':(45,50,53),'Em':(40,43,47),'D':(38,42,45),'Cm':(36,40,43),'B':(35,39,42)}
JINGLE_PROG=['C','C','C','C','F','C','G','G','C','C','C','C','F','C','G','C']
DECK_PROG=['C','C','G','C','C','C','G','C','G','C','F','G','C','C','F','C']
CAROL_PROG=['Em','Em','D','D','C','C','B','B','Em','D','C','B','Em','D','B','Em']
CAROL=[]
for b in range(16):
    if b<4 or b>=12: ns=['G5','F#5','G5','E5']
    elif b<8: ns=['B5','A5','B5','G5']
    else: ns=['E6','D#6','E6','B5']
    CAROL.append(list(zip(ns,[1,.5,.5,2])))

class Synth:
    def __init__(self,bpm,seed):
        self.bpm=bpm;self.beat=60/bpm;self.bar=4*self.beat
        self.duration=72*self.bar
        self.music=np.zeros((round(self.duration*SR),2),np.float32)
        self.drums=np.zeros_like(self.music)
        self.rng=np.random.default_rng(seed)
        self.cache={}
    def add(self,s,at,amp,pan=0,drum=False):
        i=round(at*SR)
        if i<0:s=s[-i:];i=0
        count=min(len(s),len(self.music)-i)
        if count<=0:return
        p=(np.clip(pan,-1,1)+1)*np.pi/4
        target=self.drums if drum else self.music
        target[i:i+count,0]+=s[:count]*amp*math.cos(p)
        target[i:i+count,1]+=s[:count]*amp*math.sin(p)
    def tone(self,n,dur,kind):
        key=(midi(n),round(dur,5),kind)
        if key in self.cache:return self.cache[key]
        t=np.arange(round(dur*SR),dtype=np.float32)/SR
        f=440*2**((midi(n)-69)/12)
        attack=1-np.exp(-t*250)
        release=np.minimum((dur-t)/.025,1)
        if kind=='bell':
            s=(np.sin(2*np.pi*f*t)*np.exp(-t*3.1)+.28*np.sin(2*np.pi*f*2*t)*np.exp(-t*7)+.12*np.sin(2*np.pi*f*3*t)*np.exp(-t*9))
        elif kind=='bass':
            s=(np.sin(2*np.pi*f*t)+.28*np.sin(2*np.pi*f*2*t)+.14*np.sin(2*np.pi*f*3*t))*np.exp(-t*3)
        elif kind=='brass':
            # Harmonic brass fanfare; anti-alias upper partials below Nyquist.
            s=np.zeros_like(t)
            for h in range(1,9):
                if f*h<SR*.43:s+=np.sin(2*np.pi*f*h*t)/(h**1.25)
            s*=.48*(.82+.18*np.sin(np.pi*np.minimum(t/.06,1)))
            attack=1-np.exp(-t*90)
        elif kind=='strings':
            s=np.zeros_like(t)
            for detune in [.998,1.003]:
                for h in range(1,9):
                    if f*h<SR*.43:s+=np.sin(2*np.pi*f*detune*h*t)/(h**1.5)
            s*=.23
            attack=np.minimum(t/.045,1)*np.minimum((dur-t)/.09,1)
        elif kind=='lead':
            s=np.sin(2*np.pi*f*t)+.22*np.sin(2*np.pi*f*2*t)+.12*np.sin(2*np.pi*f*3*t)
            s*=.65*np.exp(-t*1.1)
        else:
            s=(np.sin(2*np.pi*f*t)+.12*np.sin(2*np.pi*f*2*t))*np.exp(-t*5)
        value=(s*attack*release).astype(np.float32)
        self.cache[key]=value
        return value
    def note(self,n,at,dur,amp=.15,pan=0,kind='bell'):
        self.add(self.tone(n,dur,kind),at,amp,pan)
    def drum(self,kind,at,amp=1):
        length={'kick':.32,'snare':.19,'hat':.075,'sleigh':.13,'crash':1.8,'tom':.28}[kind]
        t=np.arange(round(length*SR),dtype=np.float32)/SR
        noise=self.rng.normal(0,.65,len(t)).astype(np.float32)
        high=noise-np.convolve(noise,np.ones(7)/7,'same')
        if kind=='kick':
            phase=2*np.pi*(47*t+(110/32)*(1-np.exp(-32*t)))
            s=np.sin(phase)*np.exp(-t*12)+high*.08*np.exp(-t*160)
            level=.43;pan=0
        elif kind=='snare':
            clap=np.exp(-t*33)+.55*np.exp(-np.maximum(t-.011,0)*43)*(t>.011)+.30*np.exp(-np.maximum(t-.022,0)*43)*(t>.022)
            s=high*.62*clap+.15*np.sin(2*np.pi*186*t)*np.exp(-t*35)
            level=.27;pan=-.08
        elif kind=='hat':
            s=high*np.exp(-t*65);level=.068;pan=.5
        elif kind=='sleigh':
            s=sum(np.sin(2*np.pi*f*t) for f in [2183,2931,3787,4561])/4*np.exp(-t*34)
            level=.065;pan=-.5
        elif kind=='crash':
            s=high*np.exp(-t*2.7)*(1-np.exp(-t*450));level=.22;pan=.18
        else:
            s=np.sin(2*np.pi*(88*t+.85*(1-np.exp(-t*25))))*np.exp(-t*18);level=.23;pan=-.2
        self.add(s,at,level*amp,pan,True)
    def riser(self,at,dur,amp=.10):
        t=np.arange(round(dur*SR),dtype=np.float32)/SR
        progress=t/dur
        noise=self.rng.normal(0,.35,len(t)).astype(np.float32)
        high=noise-np.convolve(noise,np.ones(17)/17,'same')
        sweep=np.sin(2*np.pi*(180*t+440*t*t/dur))*.22
        s=(high+sweep)*(progress**1.6)*np.minimum((dur-t)/.02,1)
        self.add(s,at,amp,-.35);self.add(s,at+.019,amp*.6,.55)
    def finish(self):
        # Duck the sustained instruments against each kick in the high-energy sections.
        t=np.arange(len(self.music))/SR
        bar=np.floor(t/self.bar).astype(int)
        phase=np.mod(t,self.beat)
        dropping=((bar>=8)&(bar<32))|((bar>=40)&(bar<56))|(bar>=64)
        pump=1-.40*np.exp(-phase*21)*dropping
        self.music*=pump[:,None]
        dry=self.music.copy()
        for delay,gain in [(self.beat*.75,.12),(self.beat*1.5,.075),(.069,.055),(.131,.045)]:
            n=round(delay*SR)
            self.music[n:,0]+=dry[:-n,1]*gain
            self.music[n:,1]+=dry[:-n,0]*gain
        mix=self.music+self.drums
        # The dance master uses stronger soft limiting for a forceful drop while
        # retaining the deliberately quiet opening, builds and breakdown.
        mix=np.tanh(mix*3.35)
        # Leave 1.94 dB of PCM headroom for the MP3 encoder's intersample changes.
        mix*=.80/np.max(abs(mix))
        mix[:round(.015*SR)]*=np.linspace(0,1,round(.015*SR))[:,None]
        mix[-2*SR:]*=np.linspace(1,0,2*SR)[:,None]
        return mix

def section(b):
    if b<4:return 'intro',.18
    if b<8:return 'build',.35+(b-4)*.13
    if b<24:return 'drop',1
    if b<32:return 'bridge',.85
    if b<40:return 'build',.45+(b-32)*.065
    if b<56:return 'drop2',1
    if b<64:return 'break',.48
    return 'final',1.05

def arrange(config):
    s=Synth(config['bpm'],config['seed'])
    bars=config['melody'];prog=config['progression']
    for b in range(72):
        at=b*s.bar;state,energy=section(b)
        idx=(b-8)%16
        chord=CHORDS[prog[idx]]
        tonic=64 if config['id']=='carol' else 72
        # Broader string bed, independently voiced and panned.
        for k,n in enumerate(chord):
            s.note(n+12,at,s.bar+.06,.066*energy,[-.65,0,.65][k],'strings')
        if state in ['drop','drop2','final']:
            cursor=at
            for n,length in bars[idx]:
                nn=midi(n)
                if state=='drop2' and idx>=8:nn+=12
                s.note(nn,cursor,length*s.beat*.86+.13,.30,0,'bell')
                s.note(nn-12,cursor+.004,length*s.beat*.80,.115,.14,'lead')
                cursor+=length*s.beat
            # Brass calls answer the melody; full block fanfares every fourth bar.
            if b%4 in [0,3]:
                for k,n in enumerate(chord):
                    s.note(n+24,at,s.beat*.82,.105,[-.48,0,.48][k],'brass')
                    if b%4==3:s.note(n+24,at+2*s.beat,s.beat*.82,.11,[-.4,0,.4][k],'brass')
        elif state in ['intro','build','break']:
            # Melody hints in intro and breakdown give the build musical identity.
            cursor=at
            for n,length in bars[idx]:
                s.note(n,cursor,min(length*s.beat*.80+.10,1.2),.15*energy,-.08,'bell')
                cursor+=length*s.beat
        else:
            # Bridge: the tune moves to accented synthetic brass.
            cursor=at
            for n,length in bars[idx]:
                s.note(midi(n)-12,cursor,length*s.beat*.72,.18,-.05,'brass')
                s.note(n,cursor,length*s.beat*.85,.13,.12,'bell')
                cursor+=length*s.beat
        for beat in range(4):
            when=at+beat*s.beat
            if state in ['drop','drop2','bridge','final']:
                # Four-on-the-floor dance pulse with clap/snare on 2 and 4.
                s.drum('kick',when)
                if beat%2:s.drum('snare',when)
                for half in [0,.5]:
                    s.drum('hat',when+half*s.beat,.8 if half==0 else 1.1)
                    s.drum('sleigh',when+half*s.beat,.6)
                bass=chord[0] if beat%2==0 else chord[2]-12
                s.note(bass,when+.025,s.beat*.72,.27,0,'bass')
                s.note(chord[0]+12,when+.5*s.beat,s.beat*.35,.10,-.22,'bass')
            elif state=='build':
                if b%8<6 and beat in [0,2]:s.drum('kick',when,.72)
                divisions=2 if b%8<6 else 4 if b%8==6 else 8
                for part in range(divisions):s.drum('snare',when+part*s.beat/divisions,.35+.35*energy)
                s.drum('hat',when,.65)
            elif state=='break' and beat in [0,2]:
                s.drum('kick',when,.6);s.drum('sleigh',when,.8)
            # Fast high arpeggios and tremolo strings add motion, never only tempo.
            density=4 if state in ['drop2','final'] else 2
            for sub in range(density):
                arp=chord[(beat*density+sub)%3]+24+(12 if (beat+sub)%4==3 else 0)
                s.note(arp,when+sub*s.beat/density,s.beat/density*.85,.115*energy,(-.6 if sub%2 else .6),'pluck')
            if state in ['drop2','final','bridge']:
                for n in chord:
                    s.note(n+12,when+.5*s.beat,s.beat*.32,.055*energy,.35,'strings')
        if b in [8,24,40,56,64,68]:
            s.drum('crash',at)
            if b in [8,40,64]:
                s.drum('tom',at,.9)
                for n in chord:s.note(n+24,at,s.beat*2,.14,0,'brass')
        if b in [7,39,63,67]:
            for i in range(8):s.drum('tom',at+(3+i/8)*s.beat,.65+i*.04)
    for b,length in [(4,4),(32,8),(60,4),(68,3)]:s.riser(b*s.bar,length*s.bar,.22)
    # Ignite on the first beat after the 8-bar build: musical crash + brass hit.
    s.drum('crash',8*s.bar,1.35)
    for n in CHORDS[prog[0]]:s.note(n+36,8*s.bar,s.beat,.16,[-.2,0,.2][list(CHORDS[prog[0]]).index(n)],'bell')
    return s,s.finish()

CONFIGS=[
 {'id':'jingle','file':'jingle-encendido','title':'Jingle Bells · Encendido','subtitle':'Campanas, fanfarria y dance navideño · 144 BPM','bpm':144,'seed':144,'melody':melodies['JINGLE'],'progression':JINGLE_PROG,
  'attribution':{'title':'Jingle Bells / The One Horse Open Sleigh','credit':'James Lord Pierpont, 1857. Nuevo arreglo electro-orquestal instrumental y nueva síntesis para LIGHTMAN; sin samples ni grabaciones de terceros.','url':'https://www.loc.gov/item/2023812429/'}},
 {'id':'deck','file':'deck-fiesta','title':'Deck the Halls · Fiesta','subtitle':'Guirnaldas, metales y gran celebración · 160 BPM','bpm':160,'seed':160,'melody':melodies['DECK'],'progression':DECK_PROG,
  'attribution':{'title':'Deck the Halls / Nos Galan','credit':'Melodía tradicional galesa; referencia histórica de Welsh Melodies, volumen 2 (1862). Armonización, arreglo dance e instrumentos sintetizados nuevos para LIGHTMAN.','url':'https://commons.wikimedia.org/wiki/File:Original_printed_version_of_Deck_the_Hall_with_Boughs_of_Holly.jpg'}},
 {'id':'carol','file':'carol-epico','title':'Carol of the Bells · Épico','subtitle':'Shchedryk instrumental: misterio, tensión y explosión · 168 BPM','bpm':168,'seed':168,'melody':CAROL,'progression':CAROL_PROG,
  'attribution':{'title':'Shchedryk — motivo instrumental','credit':'Motivo tradicional ucraniano asociado a Mykola Leontovych; manuscrito y estreno de 1916. Nueva transformación instrumental electro-orquestal en 4/4 para LIGHTMAN. Sin letra inglesa, voces ni grabaciones modernas.','url':'https://ui.org.ua/en/news-en/the-notes-of-shchedryk-are-now-displayed-on-one-of-the-walls-of-new-yorks-carnegie-hall/'}}
]

def cues_for(s):
    cues=[{'name':'El árbol contiene la luz · cuenta de encendido','start':0,'end':8*s.bar,'effect':'intro','palette':'gold','energy':.32},
          {'name':'¡Encendido! · golpe blanco','start':8*s.bar,'end':8*s.bar+s.beat,'effect':'burst','palette':'ice','energy':1},
          {'name':'Primer drop · espiral de Navidad','start':8*s.bar+s.beat,'end':12*s.bar,'effect':'spiral','palette':'christmas','energy':1}]
    names=[('Campanas que ascienden','comet','gold',.94),('Lazos de celebración','ribbons','candy',.97),('Abanico de luz','fan','multicolor',1),
           ('Metales y guirnaldas','checker','christmas',.84),('La fiesta abraza el árbol','rings','gold',.9),
           ('Crece la expectativa','waves','ice',.58),('Cuenta hacia la explosión','sparkle','gold',.80),
           ('Segundo drop · todo el árbol','spiral','multicolor',1),('Velocidad de estrellas','comet','candy',1),
           ('Cintas sobre el cielo','ribbons','christmas',.98),('Fanfarria de luz','fan','gold',1),
           ('Respira la Navidad','snow','ice',.46),('Un deseo antes del final','rings','gold',.7),
           ('Gran final · alegría total','finale','multicolor',1),('Última fanfarria LIGHTMAN','finale','gold',1)]
    for b,(name,effect,palette,energy) in zip(range(12,72,4),names):
        cues.append({'name':name,'start':b*s.bar,'end':min((b+4)*s.bar,s.duration),'effect':effect,'palette':palette,'energy':energy})
    assert len(cues)==18
    assert all(a['end']==b['start'] for a,b in zip(cues,cues[1:]))
    return cues

tracks=[];verification=[]
for c in CONFIGS:
    s,mix=arrange(c)
    pcm=np.round(mix*32767).astype('<i2')
    wav=OUT/(c['file']+'.wav');mp3=OUT/(c['file']+'.mp3')
    with wave.open(str(wav),'wb') as w:
        w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(wav),'-codec:a','libmp3lame','-b:a','160k','-ar','44100',str(mp3)],check=True)
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration:stream=sample_rate,channels','-of','json',str(mp3)]))
    decoded=subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-i',str(mp3),'-f','f32le','-acodec','pcm_f32le','-ar',str(SR),'-ac','2','-'])
    dec=np.frombuffer(decoded,dtype='<f4')
    ignition=s.bar*8
    track={'id':c['id'],'title':c['title'],'subtitle':c['subtitle'],'audio':'assets/audio/'+mp3.name,'audioWav':'assets/audio/'+wav.name,
           'duration':s.duration,'bpm':s.bpm,'beatsPerBar':4,'ignitionAt':ignition,'cues':cues_for(s),'attribution':c['attribution']}
    tracks.append(track)
    stats={'id':c['id'],'bars':72,'cueCount':18,'targetDuration':s.duration,'wavDuration':len(mix)/SR,'mp3ContainerDuration':float(probe['format']['duration']),
           'mp3DecodedDuration':len(dec)/2/SR,'ignitionAt':ignition,'wavPeakDbFS':float(20*np.log10(np.max(abs(mix)))),'wavRmsDbFS':float(20*np.log10(np.sqrt(np.mean(mix**2)))),
           'mp3PeakDbFS':20*np.log10(max(float(np.max(abs(dec))),1e-9)),'clippedWavSamples':int(np.count_nonzero(abs(pcm.astype(np.int32))>=32767)),
           'overrangeDecodedMp3Samples':int(np.count_nonzero(abs(dec)>=1)),
           'wavBytes':wav.stat().st_size,'mp3Bytes':mp3.stat().st_size,'rmsBy8Bars':[round(float(np.sqrt(np.mean(block**2))),5) for block in np.array_split(mix,9)]}
    verification.append(stats)
    print(json.dumps(stats,indent=2),flush=True)
(ROOT/'dist'/'tracks.json').write_text(json.dumps({'tracks':tracks},ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'music-work'/'energetic-verification.json').write_text(json.dumps(verification,indent=2),encoding='utf-8')
