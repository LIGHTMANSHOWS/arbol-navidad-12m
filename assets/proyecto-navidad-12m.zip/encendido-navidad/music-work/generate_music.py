"""Reproducible original synthesized Christmas medley. Python 3 + numpy + ffmpeg.
No samples or third-party recordings. All melodic events explicitly entered below.
"""
from pathlib import Path
import json, math, subprocess, wave
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'dist'
ASSETS = OUT / 'assets'
ASSETS.mkdir(parents=True, exist_ok=True)
SR = 22050
DURATION = 180
audio = np.zeros((SR * DURATION, 2), dtype=np.float32)
rng = np.random.default_rng(1225)

def midi(note):
    if isinstance(note, int): return note
    steps={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
    return 12*(int(note[-1])+1)+steps[note[0]]+('#' in note)-('b' in note)

def add(signal, at, level=.1, pan=0):
    start=round(at*SR)
    if start < 0: signal=signal[-start:]; start=0
    count=min(len(signal), len(audio)-start)
    if count <= 0:return
    angle=(np.clip(pan,-1,1)+1)*math.pi/4
    audio[start:start+count,0]+=signal[:count]*(level*math.cos(angle))
    audio[start:start+count,1]+=signal[:count]*(level*math.sin(angle))

def tone(note, duration, kind='bell'):
    t=np.arange(round(SR*duration),dtype=np.float32)/SR
    f=440*2**((midi(note)-69)/12)
    attack=1-np.exp(-t*140)
    if kind=='bell':
        s=(np.sin(2*np.pi*f*t)*np.exp(-t*2.2)
           +.32*np.sin(2*np.pi*f*2*t)*np.exp(-t*4.8)
           +.12*np.sin(2*np.pi*f*3*t)*np.exp(-t*7))
    elif kind=='pad':
        s=(np.sin(2*np.pi*f*t)+.2*np.sin(2*np.pi*f*2*t)+.12*np.sin(2*np.pi*f*1.002*t))
        attack=np.minimum(t/.20,1)*np.minimum((duration-t)/.35,1)
        s*=.5
    elif kind=='bass':
        s=np.sin(2*np.pi*f*t)+.18*np.sin(2*np.pi*f*2*t)
        s*=np.exp(-t*2)
    else:
        s=np.sin(2*np.pi*f*t)*np.exp(-t*5)
    release=np.minimum((duration-t)/.05,1)
    return (s*attack*release).astype(np.float32)

def note(note, at, length, level=.18, pan=0, kind='bell'):
    add(tone(note,length,kind),at,level,pan)

def melody(bars,start,bpm,repeat=2,octave=0):
    beat=60/bpm
    cursor=start
    for rep in range(repeat):
        for i,bar in enumerate(bars):
            for n,length in bar:
                nn=midi(n)+octave+(12 if rep==1 and i>=8 else 0)
                note(nn,cursor, min(length*beat*.93+ .35,2.1), .24, .13*math.sin(i))
                if rep==1:
                    note(nn-12,cursor+.014,min(length*beat*.9+.3,2),.058,-.4)
                cursor+=length*beat
    return cursor

# One melody cycle = 16 bars. The final program contains 32 bars per song.
JINGLE=[
 [('E5',1),('E5',1),('E5',2)], [('E5',1),('E5',1),('E5',2)],
 [('E5',1),('G5',1),('C5',1.5),('D5',.5)], [('E5',4)],
 [('F5',1),('F5',1),('F5',1),('F5',1)], [('F5',1),('E5',1),('E5',.5),('E5',.5),('E5',1)],
 [('E5',1),('D5',1),('D5',1),('E5',1)], [('D5',2),('G5',2)],
 [('E5',1),('E5',1),('E5',2)], [('E5',1),('E5',1),('E5',2)],
 [('E5',1),('G5',1),('C5',1.5),('D5',.5)], [('E5',4)],
 [('F5',1),('F5',1),('F5',1),('F5',1)], [('F5',1),('E5',1),('E5',.5),('E5',.5),('E5',1)],
 [('G5',1),('G5',1),('F5',1),('D5',1)], [('C5',4)]
]
DECK=[
 [('G5',1.5),('F5',.5),('E5',1),('D5',1)], [('C5',1),('D5',1),('E5',1),('C5',1)],
 [('D5',.5),('E5',.5),('F5',.5),('D5',.5),('E5',1),('D5',1)], [('C5',2),('B4',1),('C5',1)],
 [('G5',1.5),('F5',.5),('E5',1),('D5',1)], [('C5',1),('D5',1),('E5',1),('C5',1)],
 [('D5',.5),('E5',.5),('F5',.5),('D5',.5),('E5',1),('D5',1)], [('C5',2),('B4',1),('C5',1)],
 [('D5',1.5),('E5',.5),('F5',1),('D5',1)], [('E5',1.5),('F5',.5),('G5',1),('D5',1)],
 [('E5',.5),('F5',.5),('G5',1),('A5',.5),('B5',.5),('C6',1)], [('B5',2),('A5',1),('G5',1)],
 [('G5',1.5),('F5',.5),('E5',1),('D5',1)], [('C5',1),('D5',1),('E5',1),('C5',1)],
 [('A5',.5),('A5',.5),('A5',.5),('A5',.5),('G5',1),('F5',1)], [('E5',2),('D5',1),('C5',1)]
]
WISH=[
 [('C5',1),('C5',.5),('D5',.5),('C5',.5),('B4',.5)], [('A4',1),('A4',1),('A4',1)],
 [('D5',1),('D5',.5),('E5',.5),('D5',.5),('C5',.5)], [('B4',1),('G4',1),('G4',1)],
 [('E5',1),('E5',.5),('F5',.5),('E5',.5),('D5',.5)], [('C5',1),('A4',1),('G4',.5),('G4',.5)],
 [('A4',1),('D5',1),('B4',1)], [('C5',3)],
 [('C5',1),('C5',1),('C5',1)], [('B4',2),('B4',1)],
 [('C5',1),('B4',1),('A4',1)], [('G4',2),('D5',1)],
 [('E5',1),('D5',1),('C5',1)], [('G5',1),('G4',1),('G4',.5),('G4',.5)],
 [('A4',1),('D5',1),('B4',1)], [('C5',3)]
]

CHORDS={
 'C':(48,52,55), 'F':(48,53,57), 'G':(47,50,55),
 'Am':(45,48,52), 'Dm':(45,50,53), 'Em':(47,52,55)
}
PROGRESSIONS=[
 ['C','C','C','C','F','C','G','G','C','C','C','C','F','C','G','C'],
 ['C','C','G','C','C','C','G','C','G','C','F','G','C','C','F','C'],
 ['C','F','Dm','G','C','F','G','C','C','G','Am','G','C','C','G','C']
]

def drum(at,kind):
    length=.23 if kind=='kick' else .09
    t=np.arange(round(SR*length),dtype=np.float32)/SR
    if kind=='kick':
        sig=np.sin(2*np.pi*(44*t+3.8*(1-np.exp(-t*38))))*np.exp(-t*23)
        add(sig,at,.11)
    elif kind=='snare':
        noise=rng.normal(0,.3,len(t)).astype(np.float32)
        smooth=np.convolve(noise,np.ones(5)/5,'same')
        sig=(noise-smooth)*np.exp(-t*38)
        add(sig,at,.06,-.25)
    else:
        # Sleigh bells: pitched metallic partials, softened high end.
        sig=sum(np.sin(2*np.pi*f*t) for f in [1837,2411,3199,4021])/4
        sig*=np.exp(-t*50)*(1-np.exp(-t*1000))
        add(sig,at,.032,.6)

def backing(start,bpm,meter,chords,segment):
    beat=60/bpm
    for bar in range(32):
        at=start+bar*meter*beat
        triad=CHORDS[chords[bar%16]]
        # Chordal warmth with stereo spread. New voicing, not a historic arrangement.
        for k,n in enumerate(triad):
            note(n+12,at,meter*beat+.3,.034,[-.65,0,.65][k],'pad')
        for b in range(meter):
            when=at+b*beat
            bass=triad[0]-12 if b==0 else triad[2]-12
            note(bass,when,beat*.85,.135,0,'bass')
            arp=triad[b%3]+24
            note(arp,when+.5*beat,beat*.7,.055,-.65 if b%2 else .65)
            drum(when,'kick' if b==0 or (meter==4 and b==2) else 'snare')
            drum(when,'bell');drum(when+.5*beat,'bell')
        if bar%8==7:
            for k in range(4):
                drum(at+(meter-.5+k*.125)*beat,'snare')

for index,(bars,start,bpm,meter) in enumerate([(JINGLE,0,128,4),(DECK,60,128,4),(WISH,120,96,3)]):
    assert all(sum(l for _,l in bar)==meter for bar in bars)
    end=melody(bars,start,bpm)
    assert abs(end-(start+60))<1e-7
    backing(start,bpm,meter,PROGRESSIONS[index],index)

# Stereo early reflections; deterministic and bounded. No tail beyond 180 seconds.
dry=audio.copy()
for delay,gain in [(.073,.12),(.139,.08),(.227,.065),(.337,.04)]:
    samples=round(delay*SR)
    audio[samples:,0]+=dry[:-samples,1]*gain
    audio[samples:,1]+=dry[:-samples,0]*gain
# Soft bus saturation and a quiet final two-second fade preserve a seamless finish.
audio=np.tanh(audio*1.2)
audio*=.91/max(float(np.max(np.abs(audio))),1e-9)
audio[:round(.025*SR)]*=np.linspace(0,1,round(.025*SR))[:,None]
audio[-SR*2:]*=np.linspace(1,0,SR*2)[:,None]
pcm=np.round(audio*32767).astype('<i2')
wav=ASSETS/'navidad-lightman.wav'
with wave.open(str(wav),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR);f.writeframes(pcm.tobytes())
mp3=ASSETS/'navidad-lightman.mp3'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(wav),'-codec:a','libmp3lame','-b:a','128k','-ar','44100',str(mp3)],check=True)

tracks=[
 {'title':'Jingle Bells','start':0,'end':60,'bpm':128,'beatsPerBar':4,'bars':32},
 {'title':'Deck the Halls','start':60,'end':120,'bpm':128,'beatsPerBar':4,'bars':32},
 {'title':'We Wish You a Merry Christmas','start':120,'end':180,'bpm':96,'beatsPerBar':3,'bars':32}
]
choices=[
 ('La estrella despierta','sparkle','gold'),('Campanas en espiral','spiral','christmas'),
 ('Dulces de Navidad','ribbons','candy'),('Fiesta de campanas','rings','multicolor'),
 ('Copos sobre el árbol','snow','ice'),('Guirnaldas en movimiento','waves','christmas'),
 ('La magia asciende','spiral','gold'),('Brillo de celebración','sparkle','candy'),
 ('Un deseo para todos','waves','ice'),('Lazos de luz','ribbons','christmas'),
 ('El abrazo de Navidad','rings','gold'),('Gran final LIGHTMAN','finale','multicolor')
]
cues=[{'name':name,'start':i*15,'end':(i+1)*15,'effect':effect,'palette':palette,'bars':8}
      for i,(name,effect,palette) in enumerate(choices)]
sources=[
 {'title':'Jingle Bells / The One Horse Open Sleigh','credit':'James Lord Pierpont (1857); melodía histórica. Arreglo y grabación sintetizada nuevos para este proyecto.','url':'https://www.loc.gov/item/2023812429/'},
 {'title':'Deck the Halls / Nos Galan','credit':'Melodía tradicional galesa; edición histórica de Welsh Melodies (1862), volumen 2. Solo melodía instrumental; armonización nueva.','url':'https://commons.wikimedia.org/wiki/File:Original_printed_version_of_Deck_the_Hall_with_Boughs_of_Holly.jpg'},
 {'title':'We Wish You a Merry Christmas','credit':'Melodía tradicional inglesa; arreglo instrumental nuevo. Referencia de identificación del tema, sin reutilizar partituras o grabaciones modernas.','url':'https://imslp.org/wiki/Christmas_Songs_for_3_Guitars_(Sampson,_David_M.)'}
]
show={'title':'LIGHTMAN · La magia de Navidad','audio':'assets/navidad-lightman.mp3','audioWav':'assets/navidad-lightman.wav','duration':180,'sampleRate':SR,'channels':2,'tracks':tracks,'cues':cues,'notes':['Medley instrumental de campanas, celesta, pads, bajo y percusión, sintetizado especialmente para este proyecto.','Tres segmentos de 60 segundos; cambios visuales cada 8 compases, sincronizados al reloj de reproducción de audio.','No contiene voces, samples ni grabaciones de terceros.','El diseño es una previsualización musical; la ejecución en hardware requiere secuenciar/exportar los canales y validar en sitio.'],'attribution':sources}
(OUT/'show.json').write_text(json.dumps(show,ensure_ascii=False,indent=2),encoding='utf-8')
metrics={'durationSeconds':len(audio)/SR,'peakDbFS':20*math.log10(float(np.max(np.abs(audio)))),'rmsDbFS':20*math.log10(float(np.sqrt(np.mean(audio**2)))),'wavBytes':wav.stat().st_size,'mp3Bytes':mp3.stat().st_size,'clippedSamples':int(np.count_nonzero(abs(pcm.astype(np.int32))>=32767))}
(ROOT/'music-work'/'verification.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
print(json.dumps(metrics,indent=2))
